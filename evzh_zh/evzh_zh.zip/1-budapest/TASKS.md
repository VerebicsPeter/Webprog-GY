# 1. feladat: Budapest kerületei

- [x] a.
- [x] b.
- [x] c.
- [x] d.
