# 4. feladat: Idézetek

- [x] a.
- [x] b.
- [x] c.
- [ ] d.
- [ ] e.
- [ ] f.
- [ ] g.
