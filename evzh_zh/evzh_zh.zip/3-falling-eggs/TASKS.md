# 3. feladat: Potyogó tojások

- [x] a.
- [x] b.
- [ ] c.
- [ ] d.
- [ ] e.
- [ ] f.
- [ ] g.
